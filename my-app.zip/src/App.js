import './App.css';
import { useState } from 'react';
import Counter from './components/counter';
import NavBar from './components/NavBar/NavBar';


const App =(props)=> {
  const [showAddUser, setShowAddUser] = useState(false);
  const [users,setUsers]=useState(
    [
      {name:'Макс',
      phone:'80447669504',
      },
      {name:'Ваня',
      phone:'80448553604',
      },
      {name:'Влад',
      phone:'80293650202',
      }
    ]
  );
  const [user,setUser]=useState({name:'',phone:''});
  const onChange= (e)=>{
    if(e.target.id == "name"){
      setUser({...user,name: e.target.value})
    }
    else{
      setUser({...user,phone: e.target.value})
    }
  }
  console.log(user);
  return ( 
    <div className="App">
      <NavBar/>
      <div className="container">
        <div className="row">
          <div className="col s6">
            <a className="waves-effect waves-light btn m-1" 
            onClick={()=>setShowAddUser(!showAddUser)}>
              Add Users</a>
          </div>
          {showAddUser && <div className="col s6">
              <div className="input-field col s6">
              <i className="material-icons prefix">account_circle</i>
              <input onChange={onChange} id="name" type="text" className="validate" placeholder="First Name"/>
            </div>
            <div className="input-field col s6">
              <i className="material-icons prefix">phone</i>
              <input onChange={onChange} id="phone" type="tel" className="validate" placeholder="Phone Number"/>
            </div>
            <div className="col s6">
              <a className="waves-effect waves-light btn m-1" onClick={()=>setUsers([...users,user])}>Add</a>
            </div>
            <div className="col s6">
              <a className="waves-effect waves-light btn m-1" >Cancel</a>
            </div>
          </div>}
        </div>
        <table>
        <thead>
          <tr>
              <th>Name</th>
              <th>Phone number</th>
              <th>Action</th>
          </tr>
        </thead>

        <tbody>
          
            {users.map((user)=>
              <tr key={user.phone}>
                <td>{user.name}</td>
                <td>{user.phone}</td>
                <td>DELETE</td>
              </tr>
            )}
          
        </tbody>
      </table>
      </div>
    </div>
  );
}

export default App;
